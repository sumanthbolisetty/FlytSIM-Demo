from api_library import DroneController
import time


droneHandle = DroneController('84d440b0ba95c19ccd8e56a2cf0e540694798850', 'r6nRDos0',
                              'https://dev.flytbase.com/rest/ros/flytos')




print droneHandle.take_off(5.0)
print("Drawing square with side = 5.0")
print droneHandle.set_local_position(x=5.0, y=0.0, z=0.0, body_frame=True)
print droneHandle.set_local_position(x=0.0, y=0.0, z=0.0, body_frame=True)
print droneHandle.set_local_position(x=-5.0, y=0.0, z=0.0,body_frame=True)
print droneHandle.set_local_position(x=0.0, y=-5.0, z=0.0,body_frame=True)
print droneHandle.land()

#disconnect the drone
drone.disconnect()
