from api_library import DroneController
import time


droneHandle = DroneController(fb_server_url='http://localhost:80/ros/flytsim',local=True)

print "#### FlytOS local Demo ####"



print "sending takeoff command"
print droneHandle.take_off(5.0)

print "Wait for some time"
time.sleep(10.0)

print droneHandle.position_set(x=6.5, y=0, z=0, relative=False, body_frame=True)
time.sleep(5.0)
print droneHandle.position_set(x=0, y=6.5, z=0, relative=False, body_frame=True)
time.sleep(5.0)
print droneHandle.position_set(x=-6.5, y=6.5, z=0, relative=False, body_frame=True)
time.sleep(5.0)
print droneHandle.position_set(x=0, y=-6.5, z=0, relative=False, body_frame=True)
time.sleep(5.0)


print droneHandle.land(True)

# print droneHandle.position_hold()
# print droneHandle.position_set_global(37.429353, -122.083684, 5.0, 0.0, 1.0, False, False)
# print droneHandle.velocity_set(0.0, 0.0, 0.0)
# print droneHandle.rtl()
# print droneHandle.get_global_position()
# print droneHandle.get_battery_status()
# print droneHandle.get_local_position()
